import veiculo from "../models/veiculo_model.js";
import Proprietario from "../models/proprietario_model.js";
import TipoVeiculo from "../models/tipoveiculo_model.js";

export const getVeiculos = async (req, res, next) => {
    try {
        const veiculos = await veiculo.findAll();
        res.send(veiculos);
    } catch (e) {
        console.log("Erro ao acessar a tabela veiculo", e);
    }
};

export const getVeiculosPorTipo = async (req, res, next) => {
    try {
        const veiculos = await veiculo.findAll({
            where: {
                placa_veiculo: req.params.info,
            },
        });

        res.send(veiculos);
        
    } catch (e) {
        console.log("Erro ao acessar a tabela veiculo", e);
    }
};


export const getVeiculosPorProp = async (req, res, next) => {
    try {
        const veiculos = await veiculo.findAll({
            where: {
                cpf_proprietario: req.params.info,
            },
        });

        res.send(veiculos);
        
    } catch (e) {
        console.log("Erro ao acessar a tabela veiculo", e);
    }
};

export const createVeiculos = async (req, res, next) => {
    try {
        await veiculo.create(req.body);
        res.json({
            message: "Um novo registro de veiculo foi inserido",
        });
    } catch (e) {
        console.log("Erro ao inserir um novo registro de veiculo", e);
    }
};

export const updateVeiculos = async (req, res, next) => {
    try {
        await veiculo.update(req.body, {
            where: {
                placa_veiculo: req.params.placa,
            },
        });
        res.json({
            message: "O veiculo " + req.params.placa + " foi atualizado",
        });
    } catch (e) {
        console.log("Erro ao atualizar registro de veiculo!");
    }
};

export const deleteVeiculos = async (req, res, next) => {
    try {
        await veiculo.destroy({
            where: {
                placa_veiculo: req.params.placa,
            },
        });
        res.json({
            message: "O veiculo " + req.params.placa + " foi excluído",
        });
    } catch (e) {
        console.log("Erro ao excluir registro de veiculo!");
    }
};