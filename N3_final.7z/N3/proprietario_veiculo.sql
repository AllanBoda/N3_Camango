-- Criação da tabela para os proprietários
CREATE TABLE proprietario (
    cpf INT(11) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    fone VARCHAR(20) NOT NULL
);

-- Criação da tabela para os veículos
CREATE TABLE veiculo (
    placa_veiculo VARCHAR(10) PRIMARY KEY,
    modelo_veiculo VARCHAR(50) NOT NULL,
    preco_veiculo DECIMAL(10, 2) NOT NULL,
    cpf_proprietario INT(11) NOT NULL,
    FOREIGN KEY (cpf_proprietario) REFERENCES proprietario(cpf)
);

-- Criação da tabela para os tipos de veículo
CREATE TABLE tipo_veiculo (
    placa_veiculo VARCHAR(10) PRIMARY KEY,
    tipo VARCHAR(20) NOT NULL,
    FOREIGN KEY (placa_veiculo) REFERENCES veiculo(placa_veiculo)
);

-- Adiciona gatilho (trigger) para associar o tipo de veículo automaticamente
DELIMITER //
CREATE TRIGGER tr_tipo_veiculo
AFTER INSERT ON veiculo
FOR EACH ROW
BEGIN
    DECLARE tipo_veiculo VARCHAR(20);
    
    IF NEW.preco_veiculo >= 50000 AND NEW.preco_veiculo < 100000 THEN
        SET tipo_veiculo = 'luxo';
    ELSEIF NEW.preco_veiculo < 50000 THEN
        SET tipo_veiculo = 'popular';
    ELSE
        SET tipo_veiculo = 'super luxo';
    END IF;

    INSERT INTO tipo_veiculo (placa_veiculo, tipo) VALUES (NEW.placa_veiculo, tipo_veiculo);
END;
//
DELIMITER ;
