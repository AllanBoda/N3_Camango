import express from 'express';
import { getVeiculos, createVeiculos, updateVeiculos, deleteVeiculos, getVeiculosPorTipo, getVeiculosPorProp } from '../controllers/veiculo_controller.js';
import jwt from "jsonwebtoken";

const veiculoRota = express.Router();

function verifyJWT(req, res, next){
    const token = req.headers['x-access-token'];
    if (!token) return res.status(401).json({ auth: false, message: 'Não há token' });
    
    jwt.verify(token, process.env.SECRET, function(err, decoded) {
      if (err) return res.status(500).json({ auth: false, message: 'Erro com a Autenticação do Token'});
      
      // se tudo estiver ok, salva no request para uso posterior
      req.userId = decoded.id;
      next();
    });
}

veiculoRota.get('/veiculos', verifyJWT, getVeiculos);
veiculoRota.get('/veiculosTipo/:info', verifyJWT, getVeiculosPorTipo);
veiculoRota.get('/veiculosProp/:info', verifyJWT, getVeiculosPorProp);
veiculoRota.post('/veiculos', createVeiculos);
veiculoRota.put('/veiculos/:placa', updateVeiculos);
veiculoRota.delete('/veiculos/:placa', deleteVeiculos);

export default veiculoRota;