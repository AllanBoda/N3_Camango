import express from 'express';
import { getTipoVeiculos, updateTipoVeiculos, deleteTipoVeiculos } from '../controllers/tipoveiculo_controller.js';
import jwt from "jsonwebtoken";

const tipoveiculoRota = express.Router();

function verifyJWT(req, res, next){
    const token = req.headers['x-access-token'];
    if (!token) return res.status(401).json({ auth: false, message: 'Não há token' });
    
    jwt.verify(token, process.env.SECRET, function(err, decoded) {
      if (err) return res.status(500).json({ auth: false, message: 'Erro com a Autenticação do Token'});
      
      // se tudo estiver ok, salva no request para uso posterior
      req.userId = decoded.id;
      next();
    });
}

tipoveiculoRota.get('/veiculos', verifyJWT, getTipoVeiculos);
tipoveiculoRota.put('/veiculos/:placa', updateTipoVeiculos);
tipoveiculoRota.delete('/veiculos/:placa', deleteTipoVeiculos);

export default tipoveiculoRota;