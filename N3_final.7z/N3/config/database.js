import { Sequelize } from "sequelize";

const db = new Sequelize('veiculo_proprietario', 'root', '', {
    host: 'localhost',
    dialect: 'mysql'
})
export default db;