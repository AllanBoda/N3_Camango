import { Sequelize } from "sequelize";
import db from "../config/database.js";

const {DataTypes} = Sequelize;

const Veiculo = db.define('veiculo', {
    placa_veiculo: {
        type: DataTypes.STRING(10),
        primaryKey: true,
        allowNull: false,
    },
    modelo_veiculo: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    preco_veiculo: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
    },
    cpf_proprietario: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
    },
}, {
    timestamps: false,
    freezeTableName: true,
});

export default Veiculo;