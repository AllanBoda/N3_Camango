import { Sequelize } from "sequelize";
import db from "../config/database.js";

const {DataTypes} = Sequelize;

const Proprietario = db.define('proprietario', {
    cpf: {
        type: DataTypes.INTEGER(11),
        primaryKey: true,
        allowNull: false,
    },
    nome: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    fone: {
        type: DataTypes.STRING(20),
        allowNull: false,
    },
}, {
    timestamps: false,
    freezeTableName: true,
});

export default Proprietario;