import { Sequelize } from "sequelize";
import db from "../config/database.js";

const {DataTypes} = Sequelize;

const TipoVeiculo = db.define('tipo_veiculo', {
    placa_veiculo: {
        type: DataTypes.STRING(10),
        primaryKey: true,
        allowNull: false,
    },
    tipo: {
        type: DataTypes.STRING(20),
        allowNull: false,
    },
}, {
    timestamps: false,
    freezeTableName: true,
});

export default TipoVeiculo;