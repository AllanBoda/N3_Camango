import proprietario from "../models/proprietario_model.js";

export const getProprietarios = async (req, res) => {
    try {
        const proprietarios = await proprietario.findAll()
        res.send(proprietarios)
    } catch (e) {
        console.log("Erro ao acessar a tabela Profesor",e);
    }
} 

export const createProprietarios = async (req, res) => {
    try {
        await proprietario.create(req.body)
        res.json({
            "message":"Um novo registro de proprietarios foi inserido"
        })

    } catch (e) {
        console.log("Erro ao inserir um novo registro", e);

    }
}

export const updateProprietarios = async (req, res) => {
    try {
        await proprietario.update(req.body,{
            where: {
                cpf: req.params.cpf
            }
        })
        res.json({
            "message":"O proprietario " + req.params.cpf +  " foi atualizado"
        })
    } catch (e) {
        console.log("Erro ao atualizar registro proprietario!");

    }
}

export const deleteProprietarios = async (req, res) => {
    try {
        await proprietario.destroy({
            where: {
                cpf: req.params.cpf
            }
        })
        res.json({
            "message":"O proprietario " + req.params.cpf +  " foi excluído"
        })
    } catch (e) {
        console.log("Erro ao excluir registro proprietario!");

    }
}