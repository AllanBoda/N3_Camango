import tipoveiculo from "../models/tipoveiculo_model.js";

export const getTipoVeiculos = async (req, res) => {
    try {
        const veiculos = await tipoveiculo.findAll();
        res.send(veiculos);
    } catch (e) {
        console.log("Erro ao acessar a tabela tipoveiculo", e);
    }
};

export const updateTipoVeiculos = async (req, res) => {
    try {
        await tipoveiculo.update(req.body, {
            where: {
                placa_veiculo: req.params.placa,
            },
        });
        res.json({
            message: "O tipoveiculo " + req.params.placa + " foi atualizado",
        });
    } catch (e) {
        console.log("Erro ao atualizar registro de tipoveiculo!");
    }
};

export const deleteTipoVeiculos = async (req, res) => {
    try {
        await tipoveiculo.destroy({
            where: {
                placa_veiculo: req.params.placa,
            },
        });
        res.json({
            message: "O tipoveiculo " + req.params.placa + " foi excluído",
        });
    } catch (e) {
        console.log("Erro ao excluir registro de tipoveiculo!");
    }
};