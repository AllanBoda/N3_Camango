import express from 'express';
import { getTipoVeiculos, updateTipoVeiculos, deleteTipoVeiculos } from '../controllers/tipoveiculo_controller.js';

const router = express.Router();

router.get('/veiculos', getTipoVeiculos);
router.put('/veiculos/:placa', updateTipoVeiculos);
router.delete('/veiculos/:placa', deleteTipoVeiculos);

export default tipoveiculoRota;