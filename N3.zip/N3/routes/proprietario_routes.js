import express from 'express';
import { getProprietarios, createProprietarios, updateProprietarios, deleteProprietarios } from '../controllers/proprietario_controller.js';

const router = express.Router();

router.get('/proprietario', getProprietarios);
router.post('/proprietario', createProprietarios);
router.put('/proprietario/:placa', updateProprietarios);
router.delete('/proprietario/:placa', deleteProprietarios);

export default proprietarioRota;