import express from 'express';
import { getVeiculos, createVeiculos, updateVeiculos, deleteVeiculos } from '../controllers/veiculo_controller.js';

const router = express.Router();

router.get('/veiculos', getVeiculos);
router.post('/veiculos', createVeiculos);
router.put('/veiculos/:placa', updateVeiculos);
router.delete('/veiculos/:placa', deleteVeiculos);

export default veiculoRota;